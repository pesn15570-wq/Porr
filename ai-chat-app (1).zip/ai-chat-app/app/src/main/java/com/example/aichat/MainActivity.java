package com.example.aichat;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK = 1;
    private static final String PORT = "8089";
    private WebView web;
    private Process proc;
    private final StringBuilder logBuf = new StringBuilder();

    private File modelFile() { return new File(getFilesDir(), "model.gguf"); }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#0f172a"));
        getWindow().setNavigationBarColor(Color.parseColor("#0f172a"));
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        web.setBackgroundColor(Color.parseColor("#0f172a"));
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.__back && window.__back()", v -> {
            if (!"true".equals(v)) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        killServer();
    }

    private synchronized void killServer() {
        if (proc != null) {
            proc.destroy();
            proc = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(() -> copyModel(uri)).start();
    }

    private void copyModel(Uri uri) {
        String name = "model.gguf";
        long total = -1;
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0) name = c.getString(ni);
                if (si >= 0) total = c.getLong(si);
            }
        } catch (Exception ignored) { }
        File tmp = new File(getFilesDir(), "model.tmp");
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(tmp)) {
            killServer();
            byte[] buf = new byte[1 << 20];
            long done = 0;
            int last = -1, n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                if (total > 0) {
                    int pct = (int) (done * 100 / total);
                    if (pct != last) { last = pct; js("window.onCopy&&onCopy(" + pct + ")"); }
                }
            }
            out.flush();
            File dst = modelFile();
            if (dst.exists()) dst.delete();
            if (!tmp.renameTo(dst)) throw new Exception("rename failed");
            getSharedPreferences("m", 0).edit().putString("name", name).apply();
            js("window.onModelReady&&onModelReady()");
        } catch (Exception e) {
            tmp.delete();
            js("window.onModelError&&onModelError(" + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
        }
    }

    public class Bridge {
        @JavascriptInterface
        public void pickModel() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, PICK);
            });
        }

        @JavascriptInterface
        public String modelInfo() {
            File f = modelFile();
            if (!f.exists()) return "";
            String n = getSharedPreferences("m", 0).getString("name", "model.gguf");
            return "{\"name\":" + JSONObject.quote(n) + ",\"mb\":" + (f.length() / 1048576) + "}";
        }

        @JavascriptInterface
        public void deleteModel() {
            killServer();
            modelFile().delete();
        }

        @JavascriptInterface
        public synchronized void startServer(int ctx, int threads) {
            if (proc != null && serverRunning()) return;
            try {
                File exe = new File(getApplicationInfo().nativeLibraryDir, "libllama_server.so");
                if (!exe.exists()) {
                    appendLog("ไม่พบ libllama_server.so ในแอป (บิลด์ llama-server ไม่สำเร็จ?)");
                    return;
                }
                List<String> cmd = new ArrayList<>();
                cmd.add(exe.getAbsolutePath());
                cmd.add("-m"); cmd.add(modelFile().getAbsolutePath());
                cmd.add("--host"); cmd.add("127.0.0.1");
                cmd.add("--port"); cmd.add(PORT);
                cmd.add("-c"); cmd.add(String.valueOf(ctx));
                cmd.add("-t"); cmd.add(String.valueOf(threads));
                cmd.add("-np"); cmd.add("1");
                ProcessBuilder pb = new ProcessBuilder(cmd);
                pb.environment().put("LD_LIBRARY_PATH", getApplicationInfo().nativeLibraryDir);
                pb.redirectErrorStream(true);
                final Process p = pb.start();
                proc = p;
                new Thread(() -> {
                    try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                        String line;
                        while ((line = r.readLine()) != null) appendLog(line);
                    } catch (Exception ignored) { }
                }).start();
            } catch (Exception e) {
                appendLog("start error: " + e);
            }
        }

        @JavascriptInterface
        public void stopServer() { killServer(); }

        @JavascriptInterface
        public synchronized boolean serverRunning() {
            if (proc == null) return false;
            try { proc.exitValue(); return false; } catch (IllegalThreadStateException e) { return true; }
        }

        @JavascriptInterface
        public synchronized String getLog() { return logBuf.toString(); }
    }

    private synchronized void appendLog(String l) {
        logBuf.append(l).append('\n');
        if (logBuf.length() > 8000) logBuf.delete(0, logBuf.length() - 6000);
    }
}
