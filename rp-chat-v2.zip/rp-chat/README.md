# RP Chat v3
แชทสวมบทบาทกับโมเดล GGUF ที่รันในแอปเอง (llama.cpp) ไม่ต้องใช้เน็ต
วิธีบิลด์: อัปโหลด zip นี้ขึ้น GitHub + วาง build.yml ที่ .github/workflows/build.yml แล้วดูแท็บ Releases
